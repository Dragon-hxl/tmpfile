This contains a restricted set of shared scenes that can be used for generating CLEVR questions.

They were created by taking the first subset of scenes from the original CLEVR scenes files.